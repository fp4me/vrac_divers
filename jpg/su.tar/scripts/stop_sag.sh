#!/bin/ksh
# ########################################################################
# Script d'arret SNL-SAG
# Projet : SNAP ISTS
#
# Version = 7.1
# Date = 08/03/2017
# Auteurs :
#       Hubert MBA le 08/03/2017 : Refonte Linux
#       FLE | 29/06/2017 : Suppression de la verification de l etat
#
# ########################################################################

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

DATE=`date +%y%m%d`
ERROR_COUNT=0
SKIP=0
TIMEOUT_STOPSAG=600
		
#Fichier de LOG
exec 1>> $LOG_DIR/sag_snl/stop_sag.${DATE}.log 2>&1

# ************************* Arret SAG ********************
log_title "Procedure d'arret de la SAG " 

check_user swnet

if [ $SKIP -eq 0 ]
then
	echo -e "`date +%H:%M:%S` : Lancement de la commande d'arret sag_bootstrap stop"
	${SAG_HOME}/bin/sag_bootstrap stop -timeout $TIMEOUT_STOPSAG 
	resStop=$?
	if [ $resStop -eq 0 ] 
	then
		echo -e "\n--> SUCCES : La SAG est a present arr�t�e (`date +%H:%M:%S`)\n"
	else
		echo -e "\n--> ECHEC : La SAG n'a pas ete arr�t�e correctement. L'arret va �tre forc� (`date +%H:%M:%S`)\n" 
		mysendtrap warning "ATTENTION - Forcage de l'arret de la SAG suite au non fonctionnement de la procedure d'arret classique"
		let ERROR_COUNT=$ERROR_COUNT+1
	fi

	swnetIpc=$(ipcs|grep swnet)
	nbIpc=$(ipcs|grep swnet| awk 'NF' | wc -l)
	if [ $nbIpc -ne 0 ]
	then
		echo -e "\n`date +%H:%M:%S` : IPC residuels:\n`ipcs | egrep 'swnet|---|key' `\n"
		echo -e "\n`date +%H:%M:%S` : Nettoyage des IPC"
 		ipcs -s | awk  '$3 == "swnet" { system("ipcrm -s "$2) }'
		ipcs -m | awk  '$3 == "swnet" { system("ipcrm -m "$2) }'
		ipcs -q | awk  '$3 == "swnet" { system("ipcrm -q "$2) }'
	fi

	processSwnet=$(ps -fu swnet |  grep -Ev 'grep|oaw|pts' |grep swnet)
	nbProcess=$(echo -e "${processSwnet}" | awk 'NF' | wc -l )
	if [ $nbProcess -ne 0 ]
	then
 		echo -e "`date +%H:%M:%S` : Kill des process swnet\n"
		echo -e "${processSwnet}" | awk ' { print}'
 		echo -e "${processSwnet}" | awk ' { system("kill -9 " $2i) }'
	fi
else
	echo -e "`date +%H:%M:%S` : SKIP ARRET SAG -> Conditions non reunies pour l'arret SAG\n"
fi 

rm -f $TEMP_DIR/sag_system.$$
echo -e "\nFin des operations\n"
log_trailer $ERROR_COUNT "Arret de la SAG"
