#!/bin/ksh

########################################################################################################################
# Script de supervision SNL. Le but de ce script est de generer les logs puis de les analyser pour
# superviser l'etat general de l'application SNL.
#
# Version : 7.1
# Date : 08/03/2017
# Hubert MBA le 08/03/2017 : Modifications / Adapatation a Linux
# FLE        le 03/01/2018 : Refonte Linux + v7.2
########################################################################################################################


. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

DATE=`date +%y%m%d`
HEURE=`date +%H:%M:%S`
ERROR_COUNT=0

echo "sag_snl_checkintegrity.sh logging in $LOG_DIR/sag_snl/sag_snl_checkintegrity_$DATE.out"
exec 1>> $LOG_DIR/sag_snl/sag_snl_checkintegrity_$DATE.out

log_title "Verification d'integrite des softwares SNL & SAG"

check_user swnet

# Verification de l'integrite SNL
echo -e "`date +%H:%M:%S` : Verification d'integrite de l'arbo SNL"

swiftnet getconfig -i > $TEMP_DIR/getconfig.$$

cat $TEMP_DIR/getconfig.$$ | grep "Package Integrity : Successful"

if [ $? -eq 0 ]
then 
	echo -e "--> SUCCES : Integrite SNL OK\n"
else
	echo -e "--> ECHEC : Integrite SNL KO"
	echo -e "Output du swiftnet getstats -i:"
	cat $TEMP_DIR/getconfig.$$
	echo -e ""
	let ERROR_COUNT=$ERROR_COUNT+1
        mysendtrap critical "CRITIQUE : Integrite SNL KO! Contacter ME SNAP immediatement (cf log $LOG_DIR/sag_snl/sag_snl_checkintegrity_$DATE.out)"	
fi

rm -rf $TEMP_DIR/getconfig.$$


# Verification de l'integrite du software SAG 
echo -e "`date +%H:%M:%S` : Verification d'integrite de l'arbo SAG "

sag_system -- integrity > $TEMP_DIR/integrity.$$

cat $TEMP_DIR/integrity.$$ | grep "Success!"
if [ $? -eq 0 ]
then
        echo -e "--> SUCCES : Integrite SAG OK\n"
else
        echo -e "--> ECHEC : Integrite SAG KO"
        echo -e "Output du rapport d'integrite:"
        cat $TEMP_DIR/integrity.$$
	echo -e ""
        let ERROR_COUNT=$ERROR_COUNT+1
        mysendtrap critical "CRITIQUE : Integrite SAG KO! Contacter ME SNAP immediatement (cf log $LOG_DIR/sag_snl/sag_snl_checkintegrity_$DATE.out)"
fi

rm -rf $TEMP_DIR/integrity.$$


# Verification de l'integrite de la BDD SAG 
echo -e "`date +%H:%M:%S` : Verification d'integrite de la BDD SAG"

sag_system -- dbintegrity > $TEMP_DIR/dbintegrity.$$

cat $TEMP_DIR/dbintegrity.$$ | grep "SAG database integrity verification successful"
if [ $? -eq 0 ]
then
        echo -e "--> SUCCES : Integrite BDD SAG OK\n"
else
        echo -e "--> ECHEC : Integrite BDD SAG KO"
        echo -e "Output du rapport d'integrite:"
        cat $TEMP_DIR/dbintegrity.$$
        echo -e ""
	let ERROR_COUNT=$ERROR_COUNT+1
        mysendtrap critical "CRITIQUE : Integrite BDD SAG KO! Contacter ME SNAP immediatement (cf log $LOG_DIR/sag_snl/sag_snl_checkintegrity_$DATE.out)"
fi

rm -rf $TEMP_DIR/dbintegrity.$$


echo -e "\nFin des operations\n"
log_trailer $ERROR_COUNT "Verification d'integrite des softwares SNL & SAG"
