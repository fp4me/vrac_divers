#!/bin/ksh 

######################################################################################
# Script de supervision SAG & SNL. Le script est lanc� � 
# partir de la Crontab UNIX toutes les 5 minutes. 
#
# Auteur : Hubert MBA 
# Version : 7.1 
# Date : 08/03/2017
# Hubert MBA le 08/03/2017 : Adaptation au contexte Linux
#######################################################################################

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

# Sourcing de la table des plages d'arret du script
. $APPLI_DIR/scripts/scheduler.table


ERROR_COUNT=0
DATE=`date +%y%m%d`
HEURE=`date +%H:%M:%S`


echo "sag_snl_supervision.sh logging in $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out"
exec 1>> $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out 

log_title "Execution du script sag_snl_supervision.sh le $DATE � $HEURE" 

verifySchedule $0
SKIP_PROCESSING=$?

if [ $SKIP_PROCESSING -eq 0 ]
then
echo -e "`date +%H:%M:%S`: Lancement du script de supervision SNL"
if [ -x ! $APPLI_DIR/scripts/snl_supervision.sh ]
then
      echo -e "--> ECHEC: Impossible d'exectuer le script $APPLI_DIR/scripts/snl_supervision.sh\n" 
	mysendtrap major "CRITIQUE - Impossible d'exectuer le script $APPLI_DIR/scripts/snl_supervision.sh"
	let ERROR_COUNT=$ERROR_COUNT+1
else
      $APPLI_DIR/scripts/snl_supervision.sh #> /dev/null
	if [ $? -ne 0 ]
        then
		echo -e "--> ECHEC: Une erreur est survenue. Cf fichier de log snl_supervision\n"
		let ERROR_COUNT=$ERROR_COUNT+1
	else
		echo -e "--> SUCCES\n"
	fi	
fi

echo -e "`date +%H:%M:%S`: Lancement du script de supervision SAG"
if [ -x ! $APPLI_DIR/scripts/sag_supervision.sh ]
then
      echo -e "--> ECHEC: Impossible d'executer le script $APPLI_DIR/scripts/sag_supervision.sh\n"
	mysendtrap major "CRITIQUE - Impossible d'exectuer le script $APPLI_DIR/scripts/sag_supervision.sh"
	let ERROR_COUNT=$ERROR_COUNT+1
else
      $APPLI_DIR/scripts/sag_supervision.sh #> /dev/null
	if [ $? -ne 0 ]
	then
		echo -e "--> ECHEC: Une erreur est survenue. Cf fichier de log sag_supervision\n"    
		let ERROR_COUNT=$ERROR_COUNT+1
	else
		echo -e "--> SUCCES\n"
	fi
fi
fi
log_trailer $ERROR_COUNT "Fin d'execution du script sag_snl_supervision.sh" 
