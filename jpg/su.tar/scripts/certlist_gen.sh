#!/bin/ksh

#################################################################
# Script de remontee d'information sur les certificats
# SWIFTNet.
#
# Version = 1.0 date 26/06/03 : version initiale
# Version = 1.1 date 18/01/05 : prise en compte de la release 5.5
# Version = 2.0 date 27/06/2011 : prise en compte release v7
# Version = 3.0 date 07/03/2017 : Adaptation Linux (Hubert MBA)
#################################################################


. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

DATE=`date +%y%m%d`
OUTPUTFILE=$LOG_DIR/sag_snl/certlist_gen.out
ERROR_COUNT=0

exec 1>> $LOG_DIR/sag_snl/certlist_gen_${DATE}.log 2>&1

log_title "Procedure de recuperation des infos certificats"

check_user swnet

echo -e "`date +%H:%M:%S` : execution de la commande certlist"

if [ -f $SWNET_HOME/bin/certlist ]
  then
     certlist > $OUTPUTFILE
        echo -e "--> SUCCES : Fin d'execution de la commande certlist (`date +%H:%M:%S`)"
  else
     echo -e "--> ECHEC : le fichier $SWNET_HOME/bin/certlist est introuvable, impossible d'executer la commande"
        mysendtrap major "ATTENTION - impossible d'exectuer la commande certlist --> investigation necessaire"
        let ERROR_COUNT=$ERROR_COUNT+1
fi

echo -e "\nFin des operations\n"

log_trailer $ERROR_COUNT "Recuperation des infos certificats"

