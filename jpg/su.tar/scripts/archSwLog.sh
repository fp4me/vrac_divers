#! /bin/sh
#############################################################################################:q##########
# Ce Script permet d'utiliser l'executable $TOM_DIR/exit/archSwLog
# pour l'archivage du fichier swift.log. Les fichiers archivýt situýans le repertoire $TOM_DIR/exit/swlog avec le nom LAAAAMMJJ.
# Auteur : Hubert MBA
# Version : 1.1 --> Ajout fichier de log
# Version : 1.2 --> Ajout du chargement des fichiers .variable et .profile
# Date : 03/08/2017 : Refonte Linux
#######################################################################################################

# profile de ConnectExpress afin de dý l.environnement
. ~/.profile

# Variables d'environnement
. ~/.variable

#Fichier de LOG
exec 1>> $LOG_DIR/ce_swiftnet/archSwLog.${DATE}.log 2>&1


echo " ---------------------------------------------"
/usr/bin/date
echo " ---------------------------------------------"
export TOM_DIR=/produits/tom/sag`echo $SITE`
/produits/tom/sag`echo $SITE`/exit/archSwLog

echo " ---------------------------------------------"
echo " ---------------FIN---------------------------"

