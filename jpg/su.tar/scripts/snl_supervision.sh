#! /bin/ksh

########################################################################################
# Script de supervision SNL. Le but de ce script est
# de generer les logs qui vont etre analysees pour
# superviser l'etat general de l'application SNL.
#
# Auteur : HUBERT MBA ITIM/ISTS
# Version : 7.1
# Date : 14/12/2016
# Hubert MBA le 13/12/2016 : Modification Script pour ajout Linux et Suppression BSAG01
# FLE           03/01/2017 : Fix v7.2
########################################################################################

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

SW_STAT=$TEMP_DIR/swiftnet_status.out
SW_STAT_H=$TEMP_DIR/swiftnet_status_h.out
SW_STAT_C=$TEMP_DIR/swiftnet_status_c.out
SW_GETSTAT=$TEMP_DIR/swiftnet_getstats.out
SW_NETSTAT=$TEMP_DIR/tcp_netstat.out
SW_SELFTEST=$TEMP_DIR/HSM_selftest.out

DATE=`date +%y%m%d`
HEURE=`date +%H:%M:%S`
ERROR_COUNT=0

TCP_PORT=$(more $SWNET_CFG_PATH/dmconfig | sed -r 's/(.*SWITCH.*NWADDR.*):([0-9]+)\"/\2/;tx;d;:x' |head -n 1)

############################################################
# Generation des logs pour SWIFTNet Link (SNL)
############################################################

echo "snl_supervision.sh logging in $LOG_DIR/sag_snl/snl_supervision_$DATE.out"
exec 1>> $LOG_DIR/sag_snl/snl_supervision_$DATE.out

log_title "Supervision SNL"

check_user swnet

echo -e "`date +%H:%M:%S` : Generation des logs SNL pour l'analyse\n"

swiftnet status > $SW_STAT
swiftnet status -h > $SW_STAT_H
swiftnet status -c > $SW_STAT_C
swiftnet getstats > $SW_GETSTAT 2>&1
netstat -an | grep $TCP_PORT | grep ESTA | grep "192.82" > $SW_NETSTAT 
cd $SWNET_HOME/bin > /dev/null
perl SwHSMSelfTest.pl > $SW_SELFTEST
cd - > /dev/null

echo -e "`date +%H:%M:%S` : Generation des logs terminees\n"

############################################################
# 
#
#              ###  #### ####  #   # #####
#              #  # #    #   # #   #   #
#              #  # #### ####  #   #   #
#              #  # #    #   # #   #   #
#              ###  #### ####   ###    #
#
#
############################################################

############################################################
############################################################
#      Analyse des logs pour SWIFTNet Link (SNL)
############################################################
############################################################
# 
# 1. Analyse du resultat de la commande swiftnet status -h
#    on verifie l'etat des sous systemes SNL 
#

echo -e "*************************************************\n"
echo -e "`date +%H:%M:%S` : Verification de l'etat des sous systemes SNL....\n" 

cut -f "3 5" -d " " $SW_STAT > $TEMP_DIR/status.tmp
ETAT_GN_SNL=1

cat $TEMP_DIR/status.tmp | while read var1 var2 
	do
		if [[ $var1 == "" || $var2 = "Up(=2)" ]]
		then
			continue 
		else
			echo -e "--> KO : le sous systeme $var1 est dans l'etat $var2"
			let ERROR_COUNT=$ERROR_COUNT+1
			ETAT_GN_SNL=0
		fi 
	done    

if [ $ETAT_GN_SNL -eq 1 ]
then
    echo -e "--> OK : Tous les composants SNL sont demarres\n"
    if [ -f $TEMP_DIR/SS_SYS_SNL_NOK ]
    then
       rm $TEMP_DIR/SS_SYS_SNL_NOK
    fi 
else
    if [ -f $TEMP_DIR/SS_SYS_SNL_NOK ]
    then
     
       SS_SYS_SNL_VAR=`cat $TEMP_DIR/SS_SYS_SNL_NOK`
      
       if [ $SS_SYS_SNL_VAR -eq 1 ]
       then
             	echo 2 > $TEMP_DIR/SS_SYS_SNL_NOK
		let ERROR_COUNT=$ERROR_COUNT+1
             	echo -e "--> KO : Etat des sous systemes SNL NOK. Voir precedentes erreurs\n"
       fi
          
       if [ $SS_SYS_SNL_VAR -eq 2 ]
       then
             	echo 3 > $TEMP_DIR/SS_SYS_SNL_NOK
		let ERROR_COUNT=$ERROR_COUNT+1
             	echo -e "--> KO : Etat des sous systemes SNL NOK. Voir precedentes erreurs\n"
       fi
       
       if [ $SS_SYS_SNL_VAR -eq 3 ]
       then
             	echo 4 > $TEMP_DIR/SS_SYS_SNL_NOK
		let ERROR_COUNT=$ERROR_COUNT+1
             	echo -e "--> KO : Etat des sous systemes SNL NOK. Voir precedentes erreurs. Une alarme va etre remontee � PATROL\n" 
             	mysendtrap warning "IMPORTANT - Etat des sous systemes SNL NOK. Voir log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out" 
       fi
       
       if [ $SS_SYS_SNL_VAR -eq 4 ]
       then
             	echo 1 > $TEMP_DIR/SS_SYS_SNL_NOK
		let ERROR_COUNT=$ERROR_COUNT+1
             	echo -e "--> KO : Etat des sous systemes SNL NOK. Voir precedentes erreurs\n"
       fi
	
    else
       		echo 1 > $TEMP_DIR/SS_SYS_SNL_NOK 
		let ERROR_COUNT=$ERROR_COUNT+1
       		echo -e "--> KO : Etat des sous systemes SNL NOK. Une erreur va etre remontee � PATROL\n"
       		mysendtrap warning "IMPORTANT - Etat des sous systemes SNL NOK. Voir log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out"
    fi
fi

rm -f $TEMP_DIR/status.tmp

#
# 2. Analyse du resultat de la commande swiftnet status -h
#    On verifie la bonne reception des acquittements  
#    SWIFTNet. Si 4 requettes successives ne sont pas acquittees 
#    une alertes est remontee a PATROL
#

echo -e "*************************************************\n"
echo -e "`date +%H:%M:%S` : Verification de l'acquittement des HeartBeat SWIFTNet\n" 

HEARTBEAT=`grep "acked (Yes)" $SW_STAT_H | wc -l`

if [ $HEARTBEAT -eq 2 ]
then
    echo -e "--> OK : Le dernier Heartbeat emis a bien ete acquitte\n" 
    if [ -f $TEMP_DIR/HEARTBEAT_NOK ]
    then
      rm $TEMP_DIR/HEARTBEAT_NOK
    fi 
else
    if [ -f $TEMP_DIR/HEARTBEAT_NOK ]
    then
     
      HB_VAR=`cat $TEMP_DIR/HEARTBEAT_NOK`
     
      if [ $HB_VAR -eq 1 ]
      then
        	echo 2 > $TEMP_DIR/HEARTBEAT_NOK
		let ERROR_COUNT=$ERROR_COUNT+1
        	echo -e "--> KO : Acquittement de Heartbeat SNL non recu de SWIFTNet\n"      
      fi
      
      if [ $HB_VAR -eq 2 ]
      then
        	echo 3 > $TEMP_DIR/HEARTBEAT_NOK
        	let ERROR_COUNT=$ERROR_COUNT+1
		echo -e "--> KO : Acquittement de Heartbeat SNL non recu de SWIFTNet\n"      
      fi
      
      if [ $HB_VAR -eq 3 ]
      then
	        echo 4 > $TEMP_DIR/HEARTBEAT_NOK
		let ERROR_COUNT=$ERROR_COUNT+1
 	       	echo -e "--> KO : Acquittement de Heartbeat SNL non recu de SWIFTNet. Une alarme va etre remontee a PATROL\n"
        	mysendtrap warning "IMPORTANT - HeartBeat SNL NOK. Voir log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out"
      fi
       
      if [ $HB_VAR -eq 4 ]
      then
        	echo -e "KO --> Acquittement de Heartbeat SNL non recu de SWIFTNet\n"
		let ERROR_COUNT=$ERROR_COUNT+1
        	echo 1 > $TEMP_DIR/HEARTBEAT_NOK
      fi
      
    else
      		touch $TEMP_DIR/HEARTBEAT_NOK
      		echo 1 > $TEMP_DIR/HEARTBEAT_NOK 
      		echo -e "--> KO : Acquittement de Heartbeat SNL non recu de SWIFTNet. Une alarme va etre remontee a PATROL\n"
		let ERROR_COUNT=$ERROR_COUNT+1
      		mysendtrap warning "IMPORTANT - HeartBeat SNL NOK. Voir log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out"
    fi
fi


#
# 3. Analyse du resultat de la commande swiftnet getstats
#    Quand une connection a un status SUSP, une alarme est
#    rapportee
#

echo -e "*************************************************\n"
echo -e "`date +%H:%M:%S` : Verification des connections TCP vers les services TUXEDO SWIFT\n" 

grep SUSP $SW_GETSTAT > $TEMP_DIR/TCP_CONN_NOK

TCP_CONN_VAR1=`cat $TEMP_DIR/TCP_CONN_NOK | wc -l`

if [ $TCP_CONN_VAR1 -eq 0 ]
then
  echo -e "--> OK : Connections aux services TUXEDO SWIFT OK\n" 
  if [ -f $TEMP_DIR/TCP_CONN_NOK ]
  then
      rm $TEMP_DIR/TCP_CONN_NOK
  fi
else
  echo -e "--> KO : Connections KO vers les services TUXEDO SWIFT suivants :" 
  let ERROR_COUNT=$ERROR_COUNT+1 
  echo `cut -f "1" -d " " $TEMP_DIR/TCP_CONN_NOK` 
 
  if [ -f $TEMP_DIR/TCP_CONN_NOK ]
  then
     TCP_CONN_VAR2=`cat $TEMP_DIR/TCP_CONN_NOK`
         if [ $TCP_CONN_VAR2 -eq 1 ]
              then 
                echo 2 > $TEMP_DIR/TCP_CONN_NOK 
	        let ERROR_COUNT=$ERROR_COUNT+1  
		echo -e "KO --> Connections aux services TUXEDO SWIFT KO. Voir precedentes erreurs\n"	
         fi           

         if [ $TCP_CONN_VAR2 -eq 2 ]
              then 
                  echo 3 > $TEMP_DIR/TCP_CONN_NOK 
		  let ERROR_COUNT=$ERROR_COUNT+1
	          echo -e "KO --> Connections aux services TUXEDO SWIFT KO. Voir precedentes erreurs\n"	
         fi           

         if [ $TCP_CONN_VAR2 -eq 3 ]
              then 
                  echo 4 > $TEMP_DIR/TCP_CONN_NOK 
		  let ERROR_COUNT=$ERROR_COUNT+1
	          echo -e "KO --> Connections aux services TUXEDO SWIFT KO. Une alarme va etre remontee � PATROL\n"
      	       	  mysendtrap warning "Probleme de connection TCP vers certains services TUXEDO SWIFT. Voir log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out"
         fi           

         if [ $TCP_CONN_VAR2 -eq 4 ]
              then 
                  echo 1 > $TEMP_DIR/TCP_CONN_NOK 
	          let ERROR_COUNT=$ERROR_COUNT+1  
		  echo -e "KO --> Connections aux services TUXEDO SWIFT KO. Voir precedentes erreurs\n"
         fi           
   else 
      touch $TEMP_DIR/TCP_CONN_NOK
      echo 1 > $TEMP_DIR/TCP_CONN_NOK
      let ERROR_COUNT=$ERROR_COUNT+1
      echo -e "KO --> Connections aux services TUXEDO SWIFT KO. Une alarme a ete remontee � PATROL\n"
      mysendtrap warning "IMPORTANT - Connections aux services TUXEDO SWIFT KO. Voir log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out"
   fi
fi

rm $TEMP_DIR/TCP_CONN_NOK > /dev/null 2>&1


#
# 4. Analyse du contenu de la ULOG TUXEDO
#    Une alarme est remontee si un evenement Disconnected
#    n'est pas suivi d'un evenement connected sous 5 minutes
#

echo -e "*************************************************\n"
echo -e "`date +%H:%M:%S` : Verification du contenu de la ULOG TUXEDO\n" 

NOUVEAU_JOUR=0

#
# Il a ete necessaire d'ecrire cette fonction pour calculer
# la difference entre le moment o� la connection a ete perdue 
# et le moment o� elle a ete retablie. Dans le cas o� cette
# difference est superieure � 5 minutes on remonte une alerte
#

calcul_diff_entre_deux_heures()
{
    h1=`echo $1 | cut -c1-2`    # Get Start Hour
    m1=`echo $1 | cut -c3-4`    # Get Start Minute
    s1=`echo $1 | cut -c5-6`    # Get Start Second
    h2=`echo $2 | cut -c1-2`    # Get Stop Hour
    m2=`echo $2 | cut -c3-4`    # Get Stop Minute
    s2=`echo $2 | cut -c5-6`    # Get Stop Second
    s3=`expr $s2 - $s1`         # Calculate Second Difference
    if [ $s3 -lt 0 ]            # Test for Negative Seconds
    then
        s3=`expr $s3 + 60`      # If yes - add one minute...
        m1=`expr $m1 + 1`       # ... and to subtractor
    fi
    m3=`expr $m2 - $m1`         # Calculate Minute Difference
    if [ $m3 -lt 0 ]            # Test for Negative Minutes
    then
        m3=`expr $m3 + 60`      # If yes - add one hour...
        h1=`expr $h1 + 1`       # ... and to subtractor
    fi
    h3=`expr $h2 - $h1`         # Calculate Hour Difference
    if [ $h3 -lt 0 ]            # Test for Negative Hours
    then
        h3=`expr $h3 + 24`      # If yes - add one day
    fi
    return $m3
}

traitement_ULOG()
{
if [ $# -ne 0 ]
then
    #On cherche un evenements de deconnection 1130
    grep "LIBGWT_CAT:1130" $1 > $TEMP_DIR/LIBGWT_1130.out
    DISCONNECT=`cat $TEMP_DIR/LIBGWT_1130.out | wc -l`
    if [ $DISCONNECT -gt 0 ]
    then
           #On extrait l'heure et le process id de la deconnection
           cut -f 1,3 -d . $TEMP_DIR/LIBGWT_1130.out >> $TEMP_DIR/HEURE_PROCID
           #On extrait le nom du SWITCH pour lequel une connection TUXEDO a ete perdue
           cut -f 7 -d " " $TEMP_DIR/LIBGWT_1130.out >> $TEMP_DIR/SWITCH_ID
           #On fait une concatenation des deux fichiers precedants pour creer un seul fichier
           paste -d . $TEMP_DIR/HEURE_PROCID $TEMP_DIR/DATE $TEMP_DIR/SWITCH_ID >> $TEMP_DIR/HEURE_PROC_SWITCHID
    fi 
    #On cherche un evenements de reconnection 1129
    grep "LIBGWT_CAT:1129" $1 > $TEMP_DIR/LIBGWT_1129.out
    RECONNECT=`cat $TEMP_DIR/LIBGWT_1129.out | wc -l`
    if [ $RECONNECT -gt 0 ]
    then
           #On extrait l'heure et de le process id de la reconnection
           cut -f 1,3 -d . $TEMP_DIR/LIBGWT_1129.out >> $TEMP_DIR/HEURE_PROCID
           #On extrait de nom du SWITCH pour lequel une connection TUXEDO a ete reetablie 
           cut -f 8 -d " " $TEMP_DIR/LIBGWT_1129.out >> $TEMP_DIR/SWITCH_ID
           #On fait une concatenation des deux fichiers precedants pour creer un seul fichier
    fi
fi

if [ -f $TEMP_DIR/HEURE_PROCID ]
then
   rm $TEMP_DIR/HEURE_PROCID
fi

if [ -f $TEMP_DIR/SWITCH_ID ]
then
   rm $TEMP_DIR/SWITCH_ID
fi

cat $TEMP_DIR/HEURE_PROC_SWITCHID | while read var
                   do 
                      #On extrait le process ID 
                      PROC_ID=`echo $var | cut -c 8-12` 
                      #On extrait le nom du SWITCH 
                      SWITCH_ID=`echo $var | cut -c 14-`   
                      #On extrait l'heure de la perte de la connection TUXEDO
                      HEURE_DECONNECTION=`echo $var | cut -c 1-6`
                      #On detecte si on a recupere la connection ou pas encore
                      if [ -f $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT ]
                      then
                           TCP_RECONNECTED=`grep $PROC_ID $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT | grep "Connection established" | wc -l`
                      else 
                           TCP_RECONNECTED=0
                      fi     
                      if [ $TCP_RECONNECTED -eq 1 ]
                      then
                         TMP_LIGNE=`grep $PROC_ID $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT | grep "Connection established"`   
                         HEURE_RECONNECTION=`echo $TMP_LIGNE | cut -c 1-6` 
                         calcul_diff_entre_deux_heures $HEURE_DECONNECTION $HEURE_RECONNECTION 
                         DIFFERENCE_HOR_DEC_REC=$?
                         if [ $DIFFERENCE_HOR_DEC_REC -gt 4 ]
                         then
                             #On est dans un cas o� la difference entre la deconnection et la reconnection est egale ou superieure a 5 minutes
                             #On remonte une alerte     
                             echo -e "--> KO : A $HEURE_DECONNECTION une connection TUXEDO a ete perdue avec un le SWITCH $SWITCH_ID : le process id est $PROC_ID. La reconnection a eu lieu a $HEURE_RECONNECTION, soit plus de 5mn apres: Une alarme va etre remontee a PATROL"
			     let ERROR_COUNT=$ERROR_COUNT+1
		       	     mysendtrap warning "IMPORTANT : Deconnexion superieure � 5mn vers SWITCH SWIFT. Voir la log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out" 
                             grep -v $PROC_ID $TEMP_DIR/HEURE_PROC_SWITCHID > $TEMP_DIR/HEURE_PROC_SWITCHID.NEW 
                             rm $TEMP_DIR/HEURE_PROC_SWITCHID
                             mv $TEMP_DIR/HEURE_PROC_SWITCHID.NEW $TEMP_DIR/HEURE_PROC_SWITCHID
                         else
                             echo -e "--> OK : Une deconnection TUXEDO a eu lieu � $HEURE_DECONNECTION. La reconnection a eu lieu dans les 5 minutes � $HEURE_RECONNECTION : Il n'y a pas eu d'alarme Patrol remontee\n"
                             grep -v $PROC_ID $TEMP_DIR/HEURE_PROC_SWITCHID > $TEMP_DIR/HEURE_PROC_SWITCHID.NEW
                             rm $TEMP_DIR/HEURE_PROC_SWITCHID
                             mv $TEMP_DIR/HEURE_PROC_SWITCHID.NEW $TEMP_DIR/HEURE_PROC_SWITCHID
                         fi
                      else
                         echo -e "INFO --> A $HEURE_DECONNECTION une connection TUXEDO a ete perdue avec le SWITCH $SWITCH_ID : le process id est $PROC_ID" 
                         echo -e "INFO --> A `date +%H%M%S` la reconnection n'a toujours pas eu lieu" 
                         calcul_diff_entre_deux_heures $HEURE_DECONNECTION `date +%H%M%S`     
                         DIFFERENCE_HOR_DEC_REC=$?
                         if [ $DIFFERENCE_HOR_DEC_REC -gt 4 ]
                         then
			echo -e "--> KO : Une alarme a ete remontee a PATROL\n"
			mysendtrap warning "IMPORTANT : Deconnexion superieure � 5mn vers SWITCH SWIFT. Voir la log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out"
                         else
                             echo -e "INFO --> 5 Minutes ne sont pas encore ecoulees. Il n'y aura pas de remontee d'alarmes vers PATROL\n"
                         fi 
                      fi
                   done 
}

# On teste si la ULOG du jour existe
if [ -f $SWNET_LOG_PATH/ULOG.`date +%m%d%y` ]  					
then
     ULOG_DU_JOUR=$SWNET_LOG_PATH/ULOG.`date +%m%d%y`
     NB_LIGNE_ULOG=`cat $ULOG_DU_JOUR | wc -l` 
     if [ -f $TEMP_DIR/NB_LIGNE_ULOG ]
     then
        # La variable MY_VAR contient le nombre ligne qu'il y avait dans la ULOG lors du dernier traitement 
        MY_VAR=`cat $TEMP_DIR/NB_LIGNE_ULOG`
        if [ $NB_LIGNE_ULOG -gt $MY_VAR ]
        then
            #On est sur que la ULOG a ete incremente de lignes supplementaires donc on la traite
            TRAITEMENT_ULOG=1
        fi
        
        if [ $NB_LIGNE_ULOG -eq $MY_VAR ]
        then 
            #La ULOG n'a pas changee par rapport au dernier traitement donc on ne l'a traite pas 
            TRAITEMENT_ULOG=0
            echo -e "--> OK : Le contenu de la ULOG n'a pas change. Il n'y a pas eu de nouvelles deconnections lors les 5 dernieres minutes\n"
        fi
        
        if [ $MY_VAR -gt $NB_LIGNE_ULOG ]
        then
            #Ici on traite le cas ou on passe a une nouvelle journee. La nouvelle ULOG cree contient moins de lignes
            #que la ULOG (du jours precedant) lors du dernier traitement 
            echo $NB_LIGNE_ULOG > $TEMP_DIR/NB_LIGNE_ULOG
            TRAITEMENT_ULOG=1
            NOUVEAU_JOUR=1 
        fi
     else
        #On envisage le cas oe le fichier $TEMP_DIR/NB_LIGNE_ULOG n'existe pas. On le cree alors 
        echo $NB_LIGNE_ULOG > $TEMP_DIR/NB_LIGNE_ULOG 
        TRAITEMENT_ULOG=1 
     fi

     if [ $TRAITEMENT_ULOG -eq 1 ]
     then 
        #On met dans le fichier $TEMP_DIR/NB_LIGNE_ULOG le nombre exact de lignes contenues dans la ULOG.
        echo $NB_LIGNE_ULOG > $TEMP_DIR/NB_LIGNE_ULOG  
     fi
else
 
     echo -e "--> KO : La log ULOG.`date +%m%d%y` n'existe pas dans $SWNET_LOG_PATH. Bypass du traitement ULOG"
     TRAITEMENT_ULOG=0
fi

if [ $TRAITEMENT_ULOG -eq 1 ]
then
   if [ $NOUVEAU_JOUR -eq 1 ]
   then
      #Ici on traite la premiere requette de la journee. Il faut donc traiter la ULOG depuis son debut 
      #Le fichier $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT va contenir les lignes e traitees 
      tail +1 $ULOG_DU_JOUR > $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT
      traitement_ULOG $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT
   else
      #On traite la ULOG depuis la derniere ligne qu'on a traite lors de la derniere requette 
      #Le fichier $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT va contenir les lignes e traitees 
      let DEBUT_TT_ULOG=$MY_VAR+1
      tail +$DEBUT_TT_ULOG $ULOG_DU_JOUR > $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT
      traitement_ULOG $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT
   fi
fi

#On supprime les fichiers temporaires
if [ -f $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT ]
then
     rm $TEMP_DIR/ULOG_ENCOURS_DE_TRAITEMENT
fi

#On supprime les fichiers temporaires
if [ -f $TEMP_DIR/LIBGWT_1130.out ]
then
     rm $TEMP_DIR/LIBGWT_1130.out
fi

#On supprime les fichiers temporaires
if [ -f $TEMP_DIR/LIBGWT_1129.out ]
then
     rm $TEMP_DIR/LIBGWT_1129.out
fi


#
# Verification des connections TCP vers les SWITCHES de SWIFT
# On valide les connections TCP vers le port 50202 (voir ligne 
# "RSWITCH1D2      NWADDR="//SNSL01D2H202.swiftnet.sipn.swift.com:50202"
# dans le fichier $$SWNET_CFG_PATH/dmconfig)
# si on a moins de 4 connections etablies on remonte une alerte
# 

echo -e "*************************************************\n"
echo -e "`date +%H:%M:%S` : Verification des connections TCP vers SWITCH SWIFT sur le port $TCP_PORT...\n" 

NB_CONNECTION_TCP_SW=`cat $SW_NETSTAT | wc -l`

# BT-ESC/NMA-2010/06/29-Modification TEMPO en attendant correctif ME
#if [ $NB_CONNECTION_TCP_SW -ne 4 ]
if [ $NB_CONNECTION_TCP_SW -lt 4 ]
# BT-ESC/NMA-2010/06/29-Fin
then 
      echo -e "--> KO : Probleme de connection TCP vers les SWITCHES de SWIFT sur le port $TCP_PORT\n" 
      let ERROR_COUNT=$ERROR_COUNT+1
	if [ -f $TEMP_DIR/TCP_CONN_SW_NOK ]
      then

          TCP_CONN_SW_NOK_VAR=`cat $TEMP_DIR/TCP_CONN_SW_NOK`

          if [ $TCP_CONN_SW_NOK_VAR -eq 1 ]
          then
             echo 2 > $TEMP_DIR/TCP_CONN_SW_NOK
          fi

          if [ $TCP_CONN_SW_NOK_VAR -eq 2 ]
          then
             echo 3 > $TEMP_DIR/TCP_CONN_SW_NOK
          fi

          if [ $TCP_CONN_SW_NOK_VAR -eq 3 ]
          then
             echo 4 > $TEMP_DIR/TCP_CONN_SW_NOK
             
          echo -e "Une erreur va etre remontee � PATROL\n"
	mysendtrap warning "Probleme de connections TCP vers les SWITCHES SWIFT sur le port $TCP_PORT. Voir log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out" 
          fi

          if [ $TCP_CONN_SW_NOK_VAR -eq 4 ]
          then
             echo 1 > $TEMP_DIR/TCP_CONN_SW_NOK
          fi
      else
          echo 1 > $TEMP_DIR/TCP_CONN_SW_NOK
          echo -e "Une erreur va etre remontee � PATROL\n"
          mysendtrap warning "IMPORTANT - Probleme sur les connections TCP vers le port $TCP_PORT. Voir log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out" 
      fi
else 
      echo -e "--> OK : Connections TCP sur le port $TCP_PORT OK\n"
      if [ -f $TEMP_DIR/TCP_CONN_SW_NOK ]
          then 
             rm $TEMP_DIR/TCP_CONN_SW_NOK
      fi
fi

echo -e "*************************************************\n"
echo -e "`date +%H:%M:%S` : Verification du statut des HSM\n" 


NB_ERROR=`cat $SW_SELFTEST | grep "FAILED" | wc -l` 

if [ $NB_ERROR -eq 0 ]
then
	echo -e "--> OK : SelfTest HSM OK\n" 
else
	echo -e "--> KO : SelfTest HSM KO. Une alarme va etre remontee a PATROL"
	cat $SW_SELFTEST
	let ERROR_COUNT=$ERROR_COUNT+1
	mysendtrap warning "IMPORTANT - SelfTest HSM KO. Voir log $LOG_DIR/sag_snl/sag_snl_supervision_$DATE.out"	
fi


#
# Nettoyage des fichiers temporaires
#

rm -f $SW_STAT_H
rm -f $SW_STAT
rm -f $SW_STAT_C
rm -f $SW_GETSTAT
rm -f $SW_NETSTAT
rm -f $SW_SELFTEST

log_trailer $ERROR_COUNT "Supervision SNL"
echo -e "\n" 
