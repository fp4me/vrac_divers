#!/bin/ksh
# ########################################################################
# Script de demarrage SNL-SAG
# Projet : SNAP ISTS
#
# Version = 7.1 
# Date = 08/03/2017
# Auteurs :
#       Hubert MBA le 08/03/2017 : Refonte Linux
# 
# ########################################################################

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

DATE=`date +%y%m%d`
ERROR_COUNT=0
TIMEOUT_STARTSAG=600
SKIP=0

#Fichier de LOG
exec 1>> $LOG_DIR/sag_snl/start_sag.${DATE}.log 2>&1

# ************************* Arret SAG ********************
log_title "Procedure de demarrage de la SAG" 

check_user swnet

### Verif si SAG deja demarree 
echo -e "`date +%H:%M:%S` : Verification de l'etat de la SAG avant le demarrage"

${SAG_HOME}/bin/sag_system -- status System > $TEMP_DIR/sag_system.$$ 2>&1 
cat $TEMP_DIR/sag_system.$$ | grep -q "PcState>started" 
if [ $? -eq 0 ] 
then
  	echo -e "--> ECHEC : La SAG est dej� demarree. Bypass de la procedure de demarrage\n"
	cat $TEMP_DIR/sag_system.$$ 
	SKIP=1
	let ERROR_COUNT=$ERROR_COUNT+1
else
	echo -e "--> SUCCES : La SAG est bien arr�tee\n"
fi


if [ $SKIP -eq 0 ]
then
	echo -e "`date +%H:%M:%S` : Lancement de la commande de demarrage sag_bootstrap -sagstart -timeout $TIMEOUT_STARTSAG start\n"
	${SAG_HOME}/bin/sag_bootstrap -sagstart -timeout $TIMEOUT_STARTSAG start > $TEMP_DIR/sag_system.$$ 2>&1  
	RESULT_START=$?

	#On verifie dans quel etat se trouve la SAG apres demarrage
	${SAG_HOME}/bin/sag_system -- status System > $TEMP_DIR/sag_system.$$ 2>&1
	cat $TEMP_DIR/sag_system.$$ | grep -q "PcState>started" 
	RESULT_STATUS=$?
	STATE=$(cat $TEMP_DIR/sag_system.$$ | grep PcState | sed 's/<[^>]*>//g')

	if [ $RESULT_START -eq 0 ] 
	then
		if [ $RESULT_STATUS -ne 0 ] ; then
		
			echo -e "--> ECHEC : La SAG se trouve dans l'etat $STATE et n'a donc pas demarre correctement -> Investigation necessaire\n" 
			cat $TEMP_DIR/sag_system.$$ 
			mysendtrap critical "ATTENTION: un pb est survenu lors du demarrage de la SAG, qui se trouve actuellement dans l'etat$STATE -> Investigation necessaire" 
			let ERROR_COUNT=$ERROR_COUNT+1
		else
	 		echo -e "--> SUCCES : La SAG se trouve dans l'etat$STATE\n"
			cat $TEMP_DIR/sag_system.$$ 
		fi
	else
		echo -e "--> ECHEC : La commande de demarrage SAG n'a pas abouti dans le temps imparti de $TIMEOUT_STARTSAG secondes (`date +%H:%M:%S`)\n" 
		mysendtrap warning "ATTENTION : La commande de demarrage SAG n'a pas abouti dans le temps imparti de $TIMEOUT_STARTSAG secondes (`date +%H:%M:%S`) --> Investigation necessaire" 
		let ERROR_COUNT=$ERROR_COUNT+1
	fi
else
        echo -e "`date +%H:%M:%S` : SKIP DEMARRAGE SAG -> Conditions non reunies pour le demarrage SAG\n"
fi
	

rm -f $TEMP_DIR/sag_system.$$
echo -e "\nFin des operations\n"
log_trailer $ERROR_COUNT "Demarrage de la SAG"
