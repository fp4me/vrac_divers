#!/bin/ksh
# #############################################################################################
# Script de sauvegarde applicative SNL-SAG
# Projet : ISTS LINUX New Architecture
#
# Version = 7.1 
# Date = 08/03/2017 
# Auteurs :
#
#       Hubert MBA le 08/03/2017 : Refoncte complete pour Linux 
# #############################################################################################

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

DATE=`date +%y%m%d`
ERROR_COUNT=0
SKIP=0

#Fichier de LOG
echo "sauvegarde_FS_sag_snl.sh logging in $LOG_DIR/sag_snl/sauvegarde_FS_sag_snl.${DATE}.log"
exec 1>> $LOG_DIR/sag_snl/sauvegarde_FS_sag_snl.${DATE}.log 2>&1

# ************************* Arret SAG ********************
log_title "Procedure de sauvegarde des FS applicatifs SAG-SNL " 

check_user swnet 

### Verif si SAG deja demarree
echo -e "`date +%H:%M:%S` : V�rification de l'etat de la SAG avant la sauvegarde"

${SAG_HOME}/bin/sag_system -- status System > $TEMP_DIR/sag_system.$$ 2>&1

cat $TEMP_DIR/sag_system.$$ | grep -q "PcState>started"
if [ $? -eq 0 ]
then
        echo -e "ECHEC --> La SAG est demarr�e or la sauvegarde FS necessite qu'elle soit arret�e : Bypass de la procedure de sauvegarde et alerte pilotage"
	mysendtrap minor "ATTENTION - Impossible de proc�der � la sauvegarde FS de la SAG car l'application est demarr�e"
        cat $TEMP_DIR/sag_system.$$
        SKIP=1
        let ERROR_COUNT=$ERROR_COUNT+1
else
        echo -e "SUCCES --> La SAG est bien arr�t�e"
fi

# check dir
check_rep ${SAVE_FS_DIR} "Sauvegarde FS SAG-SNL"
if [ $? -ne 0 ]
then
        SKIP=1
        let ERROR_COUNT=$ERROR_COUNT+1
fi

if [ $SKIP -eq 0 ]
then
	echo -e "`date +%H:%M:%S` : Lancement de la commande de sauvegarde FS"
	HEURE=`date +%Y-%m-%d-%H%M%S`
	tar -cpz --exclude=**/lost+found** ${SNL_APPLI_DIR} ${SAG_APPLI_DIR} /etc/opt/swnet/ /var/opt/swnet /var/opt/swift /etc/hosts /etc/services ~swnet/.profile ~swnet/.fonction ~swnet/.variable > ${SAVE_FS_DIR}/SAG_SNL_FS_BACKUP_$DATE_$HEURE.tgz
	RESULT=$?
	if [ $RESULT -eq 0 ] 
	then 
		echo -e "--> SUCCES : Sauvegarde FS SAG-SNL OK (`date +%H:%M:%S`)\n"
	else
		echo -e "--> ECHEC : Un probl�me est survenu lors de la sauvegarde FS SAG-SNL (`date +%H:%M:%S`)\n" 
		mysendtrap minor "ATTENTION - Un probl�me est survenu lors de la sauvegarde FS SAG-SNL : Investigation necessaire"
		let ERROR_COUNT=$ERROR_COUNT+1
	fi
else
	echo -e "`date +%H:%M:%S` : SKIP SAUVEGARDE FS SAG-SNL -> Conditions non r�unies pour le lancement de la sauvegarde\n"
fi

echo -e "\nFin des operations\n"
log_trailer $ERROR_COUNT "Sauvegarde FS SAG-SNL"
