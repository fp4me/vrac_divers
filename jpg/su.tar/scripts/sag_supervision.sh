#! /bin/ksh
#set -x

########################################################################################
# Script de supervision SAG. Le but de ce script est
# de generer les logs qui vont etre analysees pour
# superviser l'etat general de l'application SAG.
#
# Auteur : HUBERT MBA ITIM/ISTS
# Version : 7.1
# Date : 14/12/2016
# Hubert MBA le 13/12/2016 : Modification Script pour ajout Linux et Suppression BSAG01
########################################################################################

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

MESSAGE="SWIFTAlliance Gateway connectivity test completed successfully"

DATE=`date +%y%m%d`
ERROR_COUNT=0

# Declaration des variables utilisees par les procs d'exploit SAG
export SAG_SERVER=`uname -n`

# variables specifiques aux environnements
export TYPE_ENV=`echo $SAG_SERVER |cut -c 1 | tr [A-Z] [a-z]`
export SAG_USER=swnet
SCRIPTDIR="/applis/sag${SITE}/scripts"
export SWNET_USER=$(awk -F= '$1=="SWNET_USER" {$1="";gsub(/^ +| +$/,"");print $0}' $SCRIPTDIR/.sag_supervision.props)
export SWNET_USER_PWD=$(awk -F= '$1=="SWNET_USER_PWD" {$1="";gsub(/^ +| +$/,"");print $0}' $SCRIPTDIR/.sag_supervision.props)
case $TYPE_ENV in
                    d)        export environnement=DEVELOPPEMENT
                              export SAG_PATH=sagd;;
                    h)        export environnement=HOMOLOGATION
                              export SAG_PATH=sagf;;
                    p)        export environnement=PRODUCTION
                              export SAG_PATH=sagp;;
esac

############################################################
#                 Generation des logs
############################################################

echo "sag_supervision.sh logging in $LOG_DIR/sag_snl/sag_supervision_$DATE.out"
exec 1>> $LOG_DIR/sag_snl/sag_supervision_$DATE.out

log_title "Supervision applicative de la SAG"

check_user swnet

echo -e "`date +%H:%M:%S` : Verification de l'etat general de la SAG..."

#On verifie l'etat de la SAG. Le pattern started est recherche pour qualifier l'etat demarre de la SAG
$SAG_HOME/bin/sag_system -- status system > $TEMP_DIR/sag_system.$$
ETAT_SAG=`cat $TEMP_DIR/sag_system.$$ | grep "PcState>started" | wc -l`

#On verifie l'etat de la connection vers SWIFTNet

echo -e " $SAG_HOME/bin/sag_test_connect -SnUser *********** -SnPwd ***************  \n"

$SAG_HOME/bin/sag_test_connect -SnUser $SWNET_USER -SnPwd $SWNET_USER_PWD > $TEMP_DIR/sag_test_connect.$$
ETAT_CONN_SWNET=`cat $TEMP_DIR/sag_test_connect.$$ | grep "$MESSAGE" | wc -l`

if [ $ETAT_SAG -eq 1 ]
then
       echo -e "--> SUCCES : La SAG est correctement demarree\n"
else
       echo -e "--> ECHEC : Etat de la SAG NOK\nTRACES:\n"
       echo -e "1. Resultat de la command sag_system -- status System"
       echo -e "-----------------------------------------------------"
       echo -e "`cat $TEMP_DIR/sag_system.$$`\n"
       echo -e "2. Resultat de la command sag_system -- status Overview"
       echo -e "-------------------------------------------------------"
       echo -e "`$SAG_HOME/bin/sag_system -- status Overview`\n"
       echo -e "3. Resultat de la command sag_system -- status Detailed"
       echo -e "-------------------------------------------------------"
       echo -e "`$SAG_HOME/bin/sag_system -- status Detailed`\n"
fi


echo "`date +%H:%M:%S` : Verification de la connection SWIFTNet..."

if [ $ETAT_CONN_SWNET -eq 1 ]
then
       echo -e "--> SUCCES : La connection SWIFTNet est operationnelle\n"
else
       echo -e "--> ECHEC : Probleme sur la connection SWIFTNet\n"
fi

#
# Purge des fichiers temporaires

rm -f $TEMP_DIR/sag_system.$$
rm -f $TEMP_DIR/sag_test_connect.$$

echo -e "\nFin des operations\n"
log_trailer $ERROR_COUNT "Supervision applicative de la SAG"

