#!/bin/ksh

#************************************************************************
# Script de verification des prerequis systemes SAG
#
# Version Produit = 7.1
# Date = 08/03/2017
# Auteurs :
#    Creation par Julien Poutchits (ME SNAP) le 08/04/2013
#    Modifications par Hubert MBA (ISTS) le 08/03/2017
#    FLE - 16/06/2017  Redirection du sag_supportinfo vers repertoire accessible via otawa
#************************************************************************

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

DATE=`date +%y%m%d`
HEURE=`date +%H:%M`
ERROR_COUNT=0


#tableau de definition des tests au format "commande":"resultat_attendu"
set -A VALS_A_VERIFIER "ulimit -f":unlimited "ulimit -s":10240  "ulimit -n":4096 "ulimit -c":unlimited "ulimit -d":unlimited "ulimit -t":unlimited "ulimit -m":unlimited "ulimit -u":unlimited


#Fichier de LOG
echo "sag_checksystem.sh logging in $LOG_DIR/sag_snl/sag_checksystem_${SWNET_HOST}.${DATE}.log"
exec 1>> $LOG_DIR/sag_snl/sag_checksystem_${SWNET_HOST}.${DATE}.log 2>&1

log_title "Verification des prerequis systeme SAG"

check_user swnet 

echo -e "`date +%H:%M:%S` : Verification des prerequis systeme"
i=0
patternNumber='^[0-9]+$'
while [ "${VALS_A_VERIFIER[$i]}" != "" ]
do
        COMMAND=`echo ${VALS_A_VERIFIER[$i]} | cut -d":" -f 1`
        RESULTAT=`eval $COMMAND`
        RESULTAT_ATTENDU=`echo ${VALS_A_VERIFIER[$i]} | cut -d":" -f 2`
        if ! [[ $RESULTAT_ATTENDU =~ $patternNumber ]] ; then
          resComp=-1; [ "$RESULTAT" = "$RESULTAT_ATTENDU" ] && resComp=0 
        else
          resComp=-1; [ "$RESULTAT" -ge "$RESULTAT_ATTENDU" ] && resComp=0 
        fi  

        if [[ $resComp ]]
        then
                echo -e "$COMMAND\n$RESULTAT_ATTENDU ---> OK\n"
        else
                echo -e "$COMMAND\n$RESULTAT ---> KO!   (Resultat attendu $RESULTAT_ATTENDU)\n"
                let ERROR_COUNT=$ERROR_COUNT+1
        fi
let i=$i+1
done

echo -e "`date +%H:%M:%S` : Generation du sag_supportinfo"
#touch $SAG_HOME/glassfish/glassfish/domains/domain1/logs/server_ws.log
sag_supportinfo -output ${SVGDE_DIR}/sag_supportinfo
if [ $? -eq 0 ]
then
        echo -e "--> SUCCES : sag_supportinfo OK\n"
else
        echo -e "--> ECHEC : sag_supportinfo KO\n"
fi

if [ $ERROR_COUNT -eq 0 ]
then
        echo -e "--> SUCCES : Prerequis SAG OK\n"
else
        echo -e "--> ECHEC : Prerequis SAG KO\n "
        echo -e ""
	mysendtrap minor "Minor : Prerequis SAG KO! (envoyer log $LOG_DIR/sag_snl/sag_checksystem_${SWNET_HOST}.${DATE}.log a la BAL ME SNAP"

fi

echo -e "\nFin des operations\n"

log_trailer $ERROR_COUNT "Verification prerequis SAG"
