#!/bin/ksh

# ####################################################################################################
# Script de gestion des archives/backup journalier SNL-SAG
# Projet : SNAP PAEN
#
# Version = 7.1
# Date = 08/03/2017
# Auteurs :
#       H MBA le 10/05/2016 : Ajout purge trace Oracle SAG
#       H MBA le 25/115/2016 : Adaptation scripts pour Linux
#       H FLE le 05/01/2018  : Adaptation Linux 7.2               
# ####################################################################################################

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

DATE1=`date +%d%m%Y`
DATE=`date +%y%m%d`

ERROR_COUNT=0

echo "save_arch_sag_snl.sh logging in $LOG_DIR/sag_snl/save_arch_sag_snl.${DATE}.log"
exec 1>> $LOG_DIR/sag_snl/save_arch_sag_snl.${DATE}.log 2>&1

if [[ $TYPE_ENV = "d" ]]
then
        HSMBOX1=dsnaphsm1
        HSMBOX2=dsnaphsm2
fi

if [[ $TYPE_ENV = "h" ]]
then
        HSMBOX1=hsnaphsm1
        HSMBOX2=hsnaphsm2
        ENVIRONMENT=HOMOLOGATION
fi

if [[ $TYPE_ENV = "p" ]]
then
        HSMBOX1=psnaphsm1
        HSMBOX2=psnaphsm2
        ENVIRONMENT=PRODUCTION
fi

if [[ $TYPE_ENV = "b" ]]
then
        HSMBOX1=bsnaphsm1
        HSMBOX2=bsnaphsm2
        ENVIRONMENT=PRODUCTION
fi

log_title "Lancement de la procedure d'archivage"

# check du user
check_user swnet

echo -e "`date +%H:%M:%S` : D�but de l'archivage EJA"
SKIP=0
check_rep $ARCH_EJA_DIR "Archivage des journaux EJA"
if [ $? -ne 0 ]
then
        SKIP=1
        let ERROR_COUNT=$ERROR_COUNT+1
fi


###### Verification de l'etat de la SAG (qui doit etre demarree pour effectuer l'archivage) ######

echo -e "`date +%H:%M:%S` : Verification de l'etat de la SAG (doit etre demarree pour archivage)"
${SAG_HOME}/bin/sag_system -- status System > $TEMP_DIR/sag_system.$$ 2>&1
sagSystemOut=$(${SAG_HOME}/bin/sag_system -- status System 2>&1) #> $TEMP_DIR/sag_system.$$ 2>&1
echo "$sagSystemOut" 
echo "$sagSystemOut" |  grep -q "PcState>started"  
RESULT=$?
if [ $RESULT -ne 0 ] ; then
                echo -e "--> ECHEC : Impossible de lancer l'archivage EJA: la SAG n'est pas demarree\n"
                mysendtrap major "ATTENTION - Impossible de lancer l'archivage EJA: la SAG n'est pas demarree"
                SKIP=1
                let ERROR_COUNT=$ERROR_COUNT+1
else
echo -e "--> SUCCES : La SAG est demarree\n"
fi

if [ $SKIP -eq 0 ]
then
        #### Lancement de l'archive des events SAG ####
        echo -e "`date +%H:%M:%S` : Lancement de l'archivage EJA"
        sagSystemOut=$(${SAG_HOME}/bin/sag_system -- archive 2>&1) 
        RESULT=$?
        echo "$sagSystemOut" 
        if [ $RESULT -ne 0 ] ; then
                if $(echo "$sagSystemOut" | grep -q "no events to archive") ; then
                #if cat $TEMP_DIR/sag_system.$$ | grep -q "no events to archive" ; then

                        echo -e "--> INFO : Aucun Event a archiver dans la base (`date +%H:%M:%S`)"
                else
                        echo -e "--> ECHEC : Un pb est survenu lors de l'operation d'archivage. (`date +%H:%M:%S`)\n"
                        let ERROR_COUNT=$ERROR_COUNT+1
                fi
        else
                echo -e "--> SUCCES : L'operation d'archivage s'est deroulee correctement. (`date +%H:%M:%S`)\n"
        fi
else
        echo -e "`date +%H:%M:%S` : SKIP ARCHIVAGE EJA -> Conditions non reunies pour l'archivage EJA\n"
fi

SKIP=0
echo -e "\n***********************************************\n"
echo -e "`date +%H:%M:%S` : Debut du Backup Database de la SAG"

if [ -f ${SAG_BACKUP_FILE}.${DATE}.dmp -o -f ${SAG_BACKUP_FILE}.${DATE}.dmp.gz ]
then
        echo -e "INFO - Une archive a deja ete realisee ce jour --> Suppression"
        rm -f ${SAG_BACKUP_FILE}.${DATE}*
fi

check_rep $SAG_BACKUP_DIR "Backup database de la SAG"
if [ $? -ne 0 ]
then
        SKIP=1
        let ERROR_COUNT=$ERROR_COUNT+1
fi

if [ $SKIP -eq 0 ]
then
        echo -e "`date +%H:%M:%S` : Lancement de la procedure de sag_system -- backup"
        $SAG_HOME/bin/sag_system -- backup ${SAG_BACKUP_FILE}.${DATE}
        RESULT=$?
        if [ $RESULT -ne 0 ]
        then
                let ERROR_COUNT=$ERROR_COUNT+1
                echo -e "--> ECHEC : Un pb est survenu lors du backup SAG (`date +%H:%M:%S`)\n"
                mysendtrap critical "ATTENTION - Sauvegarde de la base de donnees SAG en echec"
        else
                echo -e "--> SUCCES : Backup SAG OK\n"
                ## Compression de l'archive
                echo -e "`date +%H:%M:%S` : Compression du fichier de backup"
                gzip -v ${SAG_BACKUP_FILE}.${DATE}.dmp
                RESULT=$?
                if [ $RESULT -eq 0 ]
                then
                        echo -e "--> SUCCES : Compression backup SAG OK\n"
                else
                        let ERROR_COUNT=$ERROR_COUNT+1
                        echo -e "--> ECHEC : Compression backup SAG KO\n"
                fi
        fi
else
echo -e "`date +%H:%M:%S` : SKIP BACKUP SAG -> Conditions non reunies pour le sag_system -- backup\n"
fi

echo -e "**********************************************\n"
echo -e "`date +%H:%M:%S` : Sauvegarde des donnees SNL"

SKIP=0
check_rep $SNL_BACKUP_DIR "Sauvegarde des donnees SNL"
if [ $? -ne 0 ]
then
SKIP=1
let ERROR_COUNT=$ERROR_COUNT+1
fi

if [ $SKIP -eq 0 ]
then

        if [ -f ${SNL_BACKUP_DIR}/backup_SNL_${DATE}.tar.gz ]
        then
                echo -e "INFO - Une sauvegarde SNL Backup a deja ete realisee jour --> Suppression\n"
                rm -rf ${SNL_BACKUP_DIR}/backup_SNL_${DATE}.* $SNL_BACKUP_DIR/$DATE > /dev/null 2>&1
        fi

        echo -e "`date +%H:%M:%S` : Lancement de la procedure SNL Backup"
        perl $SWNET_HOME/bin/SNL_BackUp.pl <<!temp_id
$SNL_BACKUP_DIR/$DATE
!temp_id

        if [ $? != 0 ]
        then
                mysendtrap critical "ATTENTION - SNL Backup en echec"
                echo -e "--> ECHEC : Sauvegarde des donnees SNL backup en echec (`date +%H:%M:%S`)"
                let ERROR_COUNT=$ERROR_COUNT+1
        
        else

          tar cvf ${SNL_BACKUP_DIR}/backup_SNL_${DATE}.tar $SNL_BACKUP_DIR/$DATE/*
          gzip ${SNL_BACKUP_DIR}/backup_SNL_${DATE}.tar

          if [ $? != 0 ]
          then

                mysendtrap critical "ATTENTION - Echec de la realisation du tar du SNL Backup"
                echo -e "Echec de la realisation du tar.gz du SNL Backup : `date +%H:%M:%S`"
          else
                echo -e "\nRealisation du tar.gz des donnees SNL Backup -> OK : `date +%H:%M:%S`"
                echo -e "Le fichier resultant est ${SNL_BACKUP_DIR}/backup_SNL_${DATE}.tar.gz\n"
          fi

          if [ -d  $SNL_BACKUP_DIR/$DATE ]
          then
                /usr/bin/rm -rf $SNL_BACKUP_DIR/$DATE
          fi
        fi  
else
        echo -e "`date +%H:%M:%S` : SKIP BACKUP SNL -> Conditions non reunies pour le backup SNL\n"
fi


####### Log Apache : log tournant quotidien pour les acces Apache #######
	echo -e "\nCopie de log quotidien Apache \n"
	cd $LOG_DIR/apache
		cp -rp access_log access_log.${DATE}
		cp -rp error_log error_log.${DATE}
		> access_log
		> error_log
	echo -e "\nFin de Copie de log quotidien Apache \n"
####### Log Apache : log tournant quotidien pour les acces Apache #######

exit 0

####### Log TRACE_ORACLE SAG : log tournant quotidien pour les traces ora_sag #######
	echo -e "\nCopie de log quotidien ORACLE TRACE \n"
	cd $ORA_TRACE
		cp -rp swlstnr.log swlstnr.log.${DATE}
			> swlstnr.log
	echo -e "\nFin de Copie de log quotidien ORACLE TRACE \n"
####### Log TRACE_ORACLE SAG : log tournant quotidien pour les traces ora_sag #######

echo -e "\nFin des operations\n"

log_trailer $ERROR_COUNT "Procedure d'archivage"
