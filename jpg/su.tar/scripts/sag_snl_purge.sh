#!/bin/ksh
# ************************************************************************
# Script de purge SNL-SAG
# Projet : SNAP PAEN
#
# Version = 7.1
# Date = 14/12/2016
# Auteurs :
# H MBA le 10/05/2016 : Modification Ajout purge Traces Oracle a 30 jours
# ************************************************************************

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

DATE=`date +%y%m%d`
ERROR_COUNT=0

#Fichier de LOG
echo "sag_snl_purge.sh logging in $LOG_DIR/sag_snl/sag_snl_purge.${DATE}.log"
exec 1>> $LOG_DIR/sag_snl/sag_snl_purge.${DATE}.log 2>&1

#************************* Arret SAG ********************
log_title "Procedure de purge SAG-SNL"

check_user swnet

mypurge $LOG_DIR 30
mypurge $SNL_BACKUP_DIR 10
mypurge $SAG_BACKUP_DIR 10
mypurge $ARCH_EJA_DIR 10
mypurge $ORA_ALERT 30
mypurge $GENLOG_DIR 20
mypurge $SAG_XML 15

mypurge $SWNET_HOME/log 35 *htm
mypurge $SWNET_HOME/log 30 HSMLogs*zip
mypurge $OAW_LOG 15 agent.*
mypurge $OAW_LOG 15 serveur*
mypurge $GENLOG_DIR 12 gentrace*
mypurge $MFP_HOME/log/MFP02 15
mypurge ${SVGDE_DIR}/sag_supportinfo 30 sag_supportinfo*zip
mypurge $GENLOG_DIR 7 *sma_mfp_status_file.txt
mypurge $LOG_DIR/apache 30
mypurge $ORA_TRACE 30
mypurge $TEMP_DIR 30

echo -e "\nFin des operations\n"
log_trailer $ERROR_COUNT "Purge SAG-SNL"

