#!/bin/ksh
# ########################################################################
# Script Demarrage Apache sur SNL-SAG
# Projet : SNAP ISTS
#
# Version = 7.1
# Date = 08/03/2017
# Auteurs :
#       Hubert MBA le 08/03/2017 : Refonte Linux
#
# ########################################################################
# set -x

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

RET_COD=0
USER_OTAWA=oaw${SITE}adm
otawaDir=/applis/oaw${SITE}

check_user swnet

### Demarrage serveur.sh avec user swnet 
echo -e "`date +%H:%M:%S` : Demarrage serveur otawa avec le user swnet"
cd ${otawaDir}/agent
./serveur.sh start

### Demarrage agents avec user otawa 
echo -e "`date +%H:%M:%S` : Demarrage agents otawa avec le user swnet"
echo "cd ${otawaDir}/agent ; ./agent.sh start" | sudo su - $USER_OTAWA

#sleep 5

#ps -edf | grep -i [h]ttp > /dev/null
#if [ $? -eq 0 ]
#then
#        RET_COD=0
#else
#        RET_COD=1
#fi

exit ${RET_COD}
