#!/bin/ksh
# ########################################################################
# Script Demarrage Apache sur SNL-SAG
# Projet : SNAP ISTS
#
# Version = 7.1
# Date = 08/03/2017
# Auteurs :
#       Hubert MBA le 08/03/2017 : Refonte Linux
#
# ########################################################################
# set -x

. ~swnet/.profile
. ~swnet/.variable

RET_COD=0

echo "cd ${APPLI_DIR}/apache/domaine$APACHE_SITE ; ./start_apa_domaine$APACHE_SITE.ksh" | sudo su - $USER_APACHE

sleep 5

ps -edf | grep -i [h]ttp > /dev/null
if [ $? -eq 0 ]
then
        RET_COD=0
else
        RET_COD=1
fi

exit ${RET_COD}
