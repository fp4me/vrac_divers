#!/bin/ksh
# ########################################################################
# Script Arret Otawa sur SNL-SAG
# Projet : SNAP ISTS
#
# Version = 7.2
# Date = 22/11/2017
# Auteurs :
#       FLE le 12/11/2017 : Refonte Linux
#
# ########################################################################
# set -x

. ~swnet/.profile
. ~swnet/.variable
. ~swnet/.fonction

RET_COD=0
USER_OTAWA=oaw${SITE}adm
otawaDir=/applis/oaw${SITE}

check_user swnet

### Arret serveur.sh avec user swnet 
echo -e "`date +%H:%M:%S` : Arret serveur otawa avec le user swnet"
cd ${otawaDir}/agent
./serveur.sh stop

### Arret agents avec user otawa 
echo -e "`date +%H:%M:%S` : Arret agents otawa avec le user otawa"
echo "cd ${otawaDir}/agent ; ./agent.sh stop" | sudo su - $USER_OTAWA

#sleep 5

#ps -edf | grep -i [h]ttp > /dev/null
#if [ $? -eq 0 ]
#then
#        RET_COD=0
#else
#        RET_COD=1
#fi

exit ${RET_COD}
